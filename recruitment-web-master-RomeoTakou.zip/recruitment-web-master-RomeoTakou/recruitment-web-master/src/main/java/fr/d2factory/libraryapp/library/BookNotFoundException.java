package fr.d2factory.libraryapp.library;

public class BookNotFoundException extends RuntimeException {
	
	
	private static final long serialVersionUID = 1L;
	public BookNotFoundException() {
		super("This book does not exit in the store, it has been borrowed!");
	}


}
