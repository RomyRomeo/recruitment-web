package fr.d2factory.libraryapp.member;
import fr.d2factory.libraryapp.book.Book;
import java.util.ArrayList;

public class Riverain extends Member {

	
	public Riverain(float wallet) {
		super(wallet,60);
		this.borrowedBooks = new ArrayList<Book>();
	}

	@Override
	public void payBook(int numberOfDays) {
		
		if (numberOfDays>60) {
			float wallet = this.getWallet();
			wallet -= 60*0.10f+(numberOfDays-60)*0.20f;
			this.setWallet(wallet);
		}
		else {
			this.setWallet(this.getWallet()-numberOfDays*0.10f);
		}
	}
	
}
