package fr.d2factory.libraryapp.member;

import fr.d2factory.libraryapp.library.Library;
import fr.d2factory.libraryapp.book.Book;

import java.util.ArrayList;



/**
 * A member is a person who can borrow and return books to a {@link Library}
 * A member can be either a student or a resident
 */
public abstract class Member {
    /**
     * An initial sum of money the member has
     */
    protected float wallet; 
    protected int maxLocationDays;
    /**
     * List of borrowed books by a member
     */
    
    protected ArrayList<Book> borrowedBooks = new ArrayList<Book>();
	

    public Member() {}
	public Member(float wallet, int maxLocationDays) {
		super();
		this.wallet = wallet;
		this.maxLocationDays = maxLocationDays;
	}


	/**
     * The member should pay their books when they are returned to the library
     *
     * @param numberOfDays the number of days they kept the book
     */
    public abstract void payBook(int numberOfDays);
  
    public float getWallet() {
        return wallet;
    }

    public void setWallet(float wallet) { //changed setWallet visibility from protected to public
        this.wallet = wallet;
    }

   
    public ArrayList<Book> getBorrowedBooks() {
		return this.borrowedBooks;
	}
    
	public void addBorrowBook(Book book) {
		this.borrowedBooks.add(book);
	}
	public void removeBorrowBook(Book book) {
		this.borrowedBooks.remove(book);
	}
	
	public int getMaxlocationDays() {
		return this.maxLocationDays;
	}
    
}
