package fr.d2factory.libraryapp.member;


import fr.d2factory.libraryapp.book.Book;
import java.util.ArrayList;

public class Etudiant extends Member {

	private boolean inFirstYear;
	public Etudiant(float wallet,boolean inFirstYear) {
	    super(wallet,30);
		this.inFirstYear = inFirstYear;
		this.borrowedBooks = new ArrayList<Book>();
	}

	@Override
	public void payBook(int numberOfDays) {
		if (inFirstYear) {
			int chargedDays = numberOfDays - 15;
			if (chargedDays > 0 ) {
				this.setWallet(this.getWallet()-chargedDays*0.10f);
			}
		}
		else { this.setWallet(this.getWallet()-numberOfDays*0.10f);}
		
	}
   
}
