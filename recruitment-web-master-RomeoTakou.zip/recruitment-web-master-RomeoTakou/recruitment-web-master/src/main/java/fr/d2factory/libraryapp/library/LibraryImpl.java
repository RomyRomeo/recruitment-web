package fr.d2factory.libraryapp.library;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;

import fr.d2factory.libraryapp.book.Book;
import fr.d2factory.libraryapp.book.BookRepository;
import fr.d2factory.libraryapp.member.Member;

public class LibraryImpl implements Library {

	private BookRepository bookRepository;
	
	
	public LibraryImpl(BookRepository bookRepository) {
		super();
		this.setBookRepository(bookRepository);
	}
	@Override
	public Book borrowBook(long isbnCode, Member member, LocalDate borrowedAt) throws HasLateBooksException,BookNotFoundException {
		ArrayList<Book> memberBorrowedBooks = member.getBorrowedBooks();
		if (memberBorrowedBooks!=null && !memberBorrowedBooks.isEmpty()) {
			memberBorrowedBooks.forEach(book
					-> {
						if (ChronoUnit.DAYS.between(bookRepository.findBorrowedBookDate(book), LocalDate.now()) > member.getMaxlocationDays()) {
							throw new HasLateBooksException();
						}
					});
		}
		Book  book= bookRepository.findBook(isbnCode);
		if (book == null) {
			throw new BookNotFoundException();
		}
		bookRepository.saveBookBorrow(book,borrowedAt);
		member.addBorrowBook(book);;
		return book;
	}

	@Override
	public void returnBook(Book book, Member member) {
		
		LocalDate dateBorrow = 	bookRepository.findBorrowedBookDate(book);
		member.payBook((int)ChronoUnit.DAYS.between(dateBorrow, LocalDate.now()));
		bookRepository.saveBookReturn(book);
		member.removeBorrowBook(book);
		
	}
	public void setBookRepository(BookRepository bookRepository) {
		this.bookRepository = bookRepository;
	}

	

}
