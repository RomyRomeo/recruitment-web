package fr.d2factory.libraryapp.book;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import fr.d2factory.libraryapp.library.BookNotFoundException;

/**
 * The book repository emulates a database via 2 HashMaps
 */
public class BookRepository {
    private Map<ISBN, Book> availableBooks = new HashMap<>();
    private Map<Book, LocalDate> borrowedBooks = new HashMap<>();

    public BookRepository() {};
    
    public void addBooks(List<Book> books){
    	books.forEach(book->availableBooks.put(book.getIsbn(),book)); 	
    }

    public Book findBook(long isbnCode) throws BookNotFoundException { 
    	Book book;
    	book = 	availableBooks.entrySet().stream()
    			  .filter(entry -> entry.getKey().getIsbnCode() == isbnCode)
    			  .map(Map.Entry::getValue)
    			  .findFirst()
    			  .orElse(null);
    	if (book == null) {
    		throw new BookNotFoundException();
    	}
    	else {
    		return book;
    	}
    }

    public void saveBookBorrow(Book book, LocalDate borrowedAt){
    	availableBooks.remove(book.getIsbn());
    	borrowedBooks.put(book,borrowedAt);	
    }

    public LocalDate findBorrowedBookDate(Book book) {
    	return borrowedBooks.get(book);
    }
    public void saveBookReturn(Book book) {
    	this.availableBooks.put(book.getIsbn(), book);
    	this.borrowedBooks.remove(book);
    	
    }
}
