package fr.d2factory.libraryapp.library;

public class HasInsufficientWalletException extends RuntimeException {
	
	private static final long serialVersionUID = 1L;
	public HasInsufficientWalletException() {
		super("This member has not enough wallet to borrow a book!");
	}

}
