package fr.d2factory.libraryapp.library;

import com.fasterxml.jackson.core.JsonParseException;
//import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
//import com.fasterxml.jackson.databind.ObjectMapper;
import fr.d2factory.libraryapp.book.Book;
import fr.d2factory.libraryapp.book.BookRepository;
import fr.d2factory.libraryapp.book.ISBN;
import fr.d2factory.libraryapp.member.*;

import static org.junit.jupiter.api.Assertions.assertTrue;

//import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Do not forget to consult the README.md :)
 */
public class LibraryTest {
    
	private Library library ;
    private BookRepository bookRepository;
    private static List<Book> books;


    @BeforeEach
    void setup() throws JsonParseException, JsonMappingException, IOException {
    	
    	bookRepository = new BookRepository();
        library = new LibraryImpl(bookRepository);
        books = new ArrayList<Book>();
        
		/*
		 * ObjectMapper mapper = new ObjectMapper(); File booksJson = new
		 * File("src/test/resources/books.json"); books = mapper.readValue(booksJson,new
		 * TypeReference<List<Book>>() { });
		 */ 
		books.add(new Book("title1","author1", new ISBN(46578964513L)));
		books.add(new Book("title2","author2", new ISBN(3326456467846L)));
		 
        bookRepository.addBooks(books);
    }

    @Test
    void member_can_borrow_a_book_if_book_is_available(){
    	float wallet = 50.0f;
        Etudiant etudiant = new Etudiant(wallet,false);    
    	Book book = library.borrowBook(46578964513L, etudiant, LocalDate.now());
        Assertions.assertNotNull(book);
    }

    @Test
    void borrowed_book_is_no_longer_available(){
    	float wallet = 50.0f;
        Etudiant etudiant = new Etudiant(wallet,false);   
    	Book book = library.borrowBook(46578964513L, etudiant, LocalDate.now());
    	try {
    		library.borrowBook(book.getIsbn().getIsbnCode(), etudiant, LocalDate.now()); 
    	}catch(BookNotFoundException e) {
    		assertTrue(true);
    	}
    }

    @Test()
    void residents_are_taxed_10cents_for_each_day_they_keep_a_book(){
    	float wallet = 50.0f;
        Riverain riverain = new Riverain(wallet);
        Book book = books.get(0);
        LocalDate date = LocalDate.now().minusDays(12);//12 days ago
        library.borrowBook(book.getIsbn().getIsbnCode(), riverain, date);
        library.returnBook(book, riverain); 
        float spentMoney = 12*0.10f;
        float riverainMoneyRest = wallet - spentMoney;
        boolean bool = ((riverain.getWallet()==riverainMoneyRest));
        assertTrue(bool);
    }

    @Test
    void students_pay_10_cents_the_first_30days(){
    	float wallet = 50.0f;
        Etudiant etudiant = new Etudiant(wallet,false);  
        LocalDate date = LocalDate.now().minusDays(22);//22 days ago
        Book book = library.borrowBook(46578964513L, etudiant,date);
        library.returnBook(book, etudiant);
        boolean b = (etudiant.getWallet()==(wallet - 22*0.10f));
        assertTrue(b);
        
        
        
        
    }

    @Test
    void students_in_1st_year_are_not_taxed_for_the_first_15days(){
    	float wallet = 50.0f;
        Etudiant etudiant = new Etudiant(wallet,true);  
        LocalDate date = LocalDate.now().minusDays(14);//14 days ago
        Book book = library.borrowBook(46578964513L, etudiant,date);
        library.returnBook(book, etudiant);
        assertTrue((etudiant.getWallet()==wallet));
        
    }
    
    @Test
    void residents_pay_20cents_for_each_day_they_keep_a_book_after_the_initial_60days(){
    	float wallet = 50.0f;
        Riverain riverain = new Riverain(wallet);
        Book book = books.get(0);
        LocalDate date = LocalDate.now().minusDays(70);//70 days ago
        library.borrowBook(book.getIsbn().getIsbnCode(), riverain, date);
        library.returnBook(book, riverain); 
        float spentMoney = 60*0.10f + 10*0.20f;
        float riverainMoneyRest = wallet - spentMoney;
        boolean bool = ((riverain.getWallet()==riverainMoneyRest));
        assertTrue(bool);
        
    }

    @Test
    void members_cannot_borrow_book_if_they_have_late_books(){
    	float wallet = 50.0f;
        Etudiant etudiant = new Etudiant(wallet,false); 
        Book book_0 = books.get(0);
        Book book_1 = books.get(1);
        LocalDate date = LocalDate.now().minusDays(35);//35 days ago
        library.borrowBook(book_0.getIsbn().getIsbnCode(), etudiant,date);
        
    	try {
    		library.borrowBook(book_1.getIsbn().getIsbnCode(), etudiant, LocalDate.now()); 
    	}catch(HasLateBooksException e) { 
    		assertTrue(true);
    	}
    }
}
